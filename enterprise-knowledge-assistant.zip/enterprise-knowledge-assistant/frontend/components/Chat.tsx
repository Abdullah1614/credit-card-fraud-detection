"use client";

import { useEffect, useRef, useState } from "react";
import { api, type ChatResponse } from "@/lib/api";
import MessageView, { type UiMessage } from "./MessageView";

export default function Chat({ collection, hasDocs }: { collection: string; hasDocs: boolean }) {
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const conversation = useRef<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [messages, loading]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const question = input.trim();
    if (!question || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: question }]);
    setLoading(true);
    try {
      const r: ChatResponse = await api.chat(question, collection, conversation.current);
      conversation.current = r.conversation_id;
      setMessages((m) => [...m, { role: "assistant", content: r.answer, response: r }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "error", content: err instanceof Error ? err.message : "Something went wrong." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="chat">
      <div className="thread" aria-live="polite">
        {messages.length === 0 && (
          <div className="empty">
            <h2>{hasDocs ? "Ask about your documents" : "Start by adding documents"}</h2>
            <p>
              {hasDocs
                ? "Answers come only from the documents in this collection, and every claim links to its source."
                : "Add policies, handbooks or reports in the sidebar, then ask a question here."}
            </p>
          </div>
        )}
        {messages.map((m, i) => <MessageView key={i} message={m} />)}
        {loading && <p className="muted thinking">Searching the documents…</p>}
        <div ref={endRef} />
      </div>
      <form className="composer" onSubmit={send}>
        <label htmlFor="q" className="sr-only">Your question</label>
        <textarea
          id="q" rows={2} value={input} placeholder="Ask a question about your documents"
          onChange={(e) => setInput(e.target.value)} maxLength={2000}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }}
        />
        <button className="primary" type="submit" disabled={loading || !input.trim()}>Ask</button>
      </form>
    </main>
  );
}
