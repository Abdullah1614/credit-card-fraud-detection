"use client";

import { useCallback, useEffect, useState } from "react";
import { api, type Doc } from "@/lib/api";
import Chat from "./Chat";
import Sidebar from "./Sidebar";

export default function Workspace() {
  const [collection, setCollection] = useState("default");
  const [collections, setCollections] = useState<string[]>(["default"]);
  const [docs, setDocs] = useState<Doc[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async (col: string) => {
    try {
      const [d, c] = await Promise.all([api.documents(col), api.collections()]);
      setDocs(d);
      setCollections(Array.from(new Set(["default", col, ...c])).sort());
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load documents.");
    }
  }, []);

  useEffect(() => { refresh(collection); }, [collection, refresh]);

  return (
    <div className="shell">
      <Sidebar
        collection={collection} collections={collections} docs={docs} error={error}
        onCollection={setCollection} onChanged={() => refresh(collection)}
      />
      <Chat key={collection} collection={collection} hasDocs={docs.length > 0} />
    </div>
  );
}
