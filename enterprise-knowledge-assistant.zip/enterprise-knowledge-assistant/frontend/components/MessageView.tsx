"use client";

import { useState } from "react";
import { api, type ChatResponse } from "@/lib/api";

export type UiMessage = { role: "user" | "assistant" | "error"; content: string; response?: ChatResponse };

const STEP_LABEL: Record<string, string> = {
  rewrite: "Rewrote the question into a search query", retrieve: "Searched keywords and meaning together",
  grade: "Kept passages that matched", generate: "Wrote the answer from those passages",
  verify: "Checked every citation", abstain: "Found nothing relevant, so declined to answer",
};

function describe(step: Record<string, unknown>): string {
  const base = STEP_LABEL[step.step as string] ?? String(step.step);
  if (step.step === "retrieve") return `${base} (${step.candidates} candidates)`;
  if (step.step === "grade") return `${base} (${step.kept} kept)`;
  return base;
}

export default function MessageView({ message }: { message: UiMessage }) {
  const [active, setActive] = useState<number | null>(null);
  const [vote, setVote] = useState<1 | -1 | null>(null);
  const [showTrace, setShowTrace] = useState(false);
  const r = message.response;

  if (message.role === "user") return <div className="msg user"><p>{message.content}</p></div>;
  if (message.role === "error") return <div className="msg error" role="alert"><p>{message.content}</p></div>;

  const parts = message.content.split(/(\[\d+\])/g);

  async function rate(v: 1 | -1) {
    if (!r || vote) return;
    setVote(v);
    try { await api.feedback(r.message_id, v); } catch { setVote(null); }
  }

  return (
    <div className="msg assistant">
      <p className="answer">
        {parts.map((p, i) => {
          const m = p.match(/^\[(\d+)\]$/);
          if (!m) return <span key={i}>{p}</span>;
          const n = Number(m[1]);
          return (
            <button key={i} className={`cite ${active === n ? "on" : ""}`} onClick={() => setActive(active === n ? null : n)}
              aria-label={`Source ${n}`} aria-pressed={active === n}>{n}</button>
          );
        })}
      </p>

      {r && !r.grounded && !r.abstained && (
        <p className="warning" role="note">This answer has no verified source. Check the documents before relying on it.</p>
      )}

      {r && r.citations.length > 0 && (
        <ol className="sources" aria-label="Sources">
          {r.citations.map((c) => (
            <li key={c.chunk_id} className={active === c.index ? "active" : ""}>
              <button className="source-head" onClick={() => setActive(active === c.index ? null : c.index)} aria-expanded={active === c.index}>
                <span className="cite static">{c.index}</span>
                <span className="source-title">{c.filename}{c.heading ? ` › ${c.heading}` : ""}</span>
              </button>
              {active === c.index && <blockquote>{c.snippet}</blockquote>}
            </li>
          ))}
        </ol>
      )}

      {r && (
        <div className="meta">
          <button className="link" onClick={() => setShowTrace(!showTrace)} aria-expanded={showTrace}>
            {showTrace ? "Hide how this was found" : "How this was found"}
          </button>
          {r.cached && <span className="muted">Saved answer</span>}
          <span className="spacer" />
          <button className={`icon-btn ${vote === 1 ? "chosen" : ""}`} onClick={() => rate(1)} disabled={vote !== null}>Helpful</button>
          <button className={`icon-btn ${vote === -1 ? "chosen" : ""}`} onClick={() => rate(-1)} disabled={vote !== null}>Not helpful</button>
        </div>
      )}
      {r && showTrace && (
        <ul className="trace">
          {r.trace.map((s, i) => <li key={i}>{describe(s)}</li>)}
          <li className="muted">Search query: {r.query}</li>
        </ul>
      )}
    </div>
  );
}
