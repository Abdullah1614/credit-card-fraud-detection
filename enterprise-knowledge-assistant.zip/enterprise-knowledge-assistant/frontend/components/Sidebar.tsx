"use client";

import { useRef, useState } from "react";
import { api, type Doc } from "@/lib/api";

type Props = {
  collection: string; collections: string[]; docs: Doc[]; error: string | null;
  onCollection: (c: string) => void; onChanged: () => void;
};

export default function Sidebar({ collection, collections, docs, error, onCollection, onChanged }: Props) {
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [newName, setNewName] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    const notes: string[] = [];
    for (const f of Array.from(files)) {
      try {
        const r = await api.upload(f, collection);
        notes.push(r.duplicate ? `${f.name} was already uploaded.` : `${f.name} added (${r.n_chunks} sections).`);
      } catch (e) {
        notes.push(`${f.name}: ${e instanceof Error ? e.message : "upload failed"}`);
      }
    }
    setStatus(notes.join(" "));
    setBusy(false);
    if (fileRef.current) fileRef.current.value = "";
    onChanged();
  }

  async function remove(d: Doc) {
    if (!window.confirm(`Remove ${d.filename}? Answers will no longer use it.`)) return;
    try { await api.remove(d.id); setStatus(`${d.filename} removed.`); onChanged(); }
    catch (e) { setStatus(e instanceof Error ? e.message : "Could not remove the document."); }
  }

  function createCollection(e: React.FormEvent) {
    e.preventDefault();
    const name = newName.trim();
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(name)) { setStatus("Use letters, numbers, - or _ for a collection name."); return; }
    setNewName(""); setStatus(null); onCollection(name);
  }

  return (
    <aside className="sidebar" aria-label="Documents">
      <h1 className="brand">Knowledge Assistant</h1>

      <label className="field-label" htmlFor="collection">Collection</label>
      <select id="collection" value={collection} onChange={(e) => onCollection(e.target.value)}>
        {collections.map((c) => <option key={c} value={c}>{c}</option>)}
      </select>
      <form onSubmit={createCollection} className="inline-form">
        <input aria-label="New collection name" placeholder="New collection" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button type="submit" className="ghost">Create</button>
      </form>

      <h2 className="section-title">Documents in {collection}</h2>
      {error && <p className="error" role="alert">{error}</p>}
      {docs.length === 0 && !error && <p className="muted">No documents yet. Add PDF, Markdown or text files.</p>}
      <ul className="doc-list">
        {docs.map((d) => (
          <li key={d.id}>
            <span className="doc-name" title={d.filename}>{d.filename}</span>
            <span className="muted">{d.n_chunks} sections</span>
            <button className="icon-btn" onClick={() => remove(d)} aria-label={`Remove ${d.filename}`}>Remove</button>
          </li>
        ))}
      </ul>

      <input ref={fileRef} id="file" type="file" multiple accept=".pdf,.md,.txt" hidden onChange={(e) => upload(e.target.files)} />
      <button className="primary full" disabled={busy} onClick={() => fileRef.current?.click()}>
        {busy ? "Adding documents…" : "Add documents"}
      </button>
      <p className="muted" aria-live="polite">{status}</p>
    </aside>
  );
}
