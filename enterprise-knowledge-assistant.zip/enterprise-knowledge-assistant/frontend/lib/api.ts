export type Citation = {
  index: number; chunk_id: string; document_id: string; filename: string; heading: string; snippet: string; score: number;
};
export type TraceStep = { step: string; [key: string]: unknown };
export type ChatResponse = {
  conversation_id: string; message_id: string; answer: string; citations: Citation[]; grounded: boolean;
  abstained: boolean; cached: boolean; trace: TraceStep[]; query: string;
};
export type Doc = { id: string; collection: string; filename: string; n_chunks: number; created_at: string };

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`/api${path}`, init);
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = Array.isArray(body.detail) ? body.detail.map((d: { msg: string }) => d.msg).join("; ") : body.detail ?? detail;
    } catch { /* keep status text */ }
    throw new Error(detail);
  }
  return res.status === 204 ? (undefined as T) : res.json();
}

export const api = {
  collections: () => request<{ collections: string[] }>("/collections").then((r) => r.collections),
  documents: (collection: string) =>
    request<{ documents: Doc[] }>(`/documents?collection=${encodeURIComponent(collection)}`).then((r) => r.documents),
  upload: (file: File, collection: string) => {
    const form = new FormData();
    form.append("file", file);
    form.append("collection", collection);
    return request<Doc & { duplicate: boolean }>("/documents", { method: "POST", body: form });
  },
  remove: (id: string) => request<void>(`/documents/${id}`, { method: "DELETE" }),
  chat: (question: string, collection: string, conversationId: string | null) =>
    request<ChatResponse>("/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, collection, conversation_id: conversationId }),
    }),
  feedback: (messageId: string, rating: 1 | -1) =>
    request<{ id: string }>("/feedback", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message_id: messageId, rating }),
    }),
};
