import { NextRequest } from "next/server";

// Server-side proxy: the browser talks to /api/*, and this forwards to the backend with the secret API key,
// so the key never reaches the client and no CORS setup is needed.
const BACKEND = process.env.BACKEND_URL ?? "http://localhost:8000";

async function handler(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  const { path } = await ctx.params;
  const headers = new Headers();
  const contentType = req.headers.get("content-type");
  if (contentType) headers.set("content-type", contentType);
  if (process.env.API_KEY) headers.set("x-api-key", process.env.API_KEY);

  const hasBody = !["GET", "HEAD", "DELETE"].includes(req.method);
  const init: RequestInit & { duplex?: "half" } = { method: req.method, headers };
  if (hasBody) { init.body = req.body; init.duplex = "half"; }

  try {
    const res = await fetch(`${BACKEND}/${path.join("/")}${req.nextUrl.search}`, init);
    return new Response(res.status === 204 ? null : res.body, {
      status: res.status,
      headers: { "content-type": res.headers.get("content-type") ?? "application/json" },
    });
  } catch {
    return Response.json({ detail: "The knowledge service is not reachable." }, { status: 502 });
  }
}

export { handler as GET, handler as POST, handler as DELETE };
