from app.agent.graph import verify_citations
from app.llm.generators import ABSTAIN_TEXT
from app.retrieval.hybrid import Retrieved
from tests.conftest import make_settings
from app.services import Services


def _ctx(n):
    return [Retrieved(f"c{i}", "d", "f.md", "H", f"text {i}", 1, 1, 0.1, 0.9) for i in range(1, n + 1)]


def test_verify_strips_invalid_citations():
    answer, cites, grounded = verify_citations("Fact one [1]. Fact two [7].", _ctx(2))
    assert "[7]" not in answer and "[1]" in answer
    assert [c["index"] for c in cites] == [1] and grounded


def test_verify_flags_uncited_answers():
    _, cites, grounded = verify_citations("An answer with no citations.", _ctx(2))
    assert cites == [] and grounded is False


def test_answerable_question_is_grounded_and_cited(services):
    out = services.agent("How many days of annual leave do I get?", "default")
    assert out["grounded"] and not out["abstained"]
    assert "24 days" in out["answer"]
    assert out["citations"][0]["filename"] == "employee-handbook.md"
    assert [t["step"] for t in out["trace"]] == ["rewrite", "retrieve", "grade", "generate", "verify"]


def test_unanswerable_question_abstains_after_retry(services):
    out = services.agent("What is the capital of Mars?", "default")
    assert out["abstained"] and out["answer"] == ABSTAIN_TEXT and out["citations"] == []
    steps = [t["step"] for t in out["trace"]]
    assert steps.count("retrieve") == services.settings.max_attempts and steps[-1] == "abstain"


def test_follow_up_uses_history_to_rewrite(services):
    history = [{"role": "user", "content": "How many days of annual leave do I get?"},
               {"role": "assistant", "content": "24 days [1]."}]
    out = services.agent("and carried over?", "default", history)
    assert "annual leave" in out["query"]
    assert out["grounded"] and "carried" in out["answer"]


def test_empty_collection_abstains(services):
    assert services.agent("anything about leave?", "no-such-collection")["abstained"]
