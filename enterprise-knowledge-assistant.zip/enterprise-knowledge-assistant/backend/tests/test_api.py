from fastapi.testclient import TestClient

from app.main import create_app
from app.services import Services
from tests.conftest import make_settings


def test_health(client):
    body = client.get("/health").json()
    assert body["status"] == "ok" and body["documents"] == 4


def test_upload_list_and_delete(client):
    r = client.post("/documents", files={"file": ("faq.md", b"# FAQ\n\n## Parking\nParking is free for staff.")},
                    data={"collection": "facilities"})
    assert r.status_code == 201 and r.json()["n_chunks"] == 1 and not r.json()["duplicate"]
    doc_id = r.json()["id"]
    assert [d["filename"] for d in client.get("/documents", params={"collection": "facilities"}).json()["documents"]] == ["faq.md"]
    assert "facilities" in client.get("/collections").json()["collections"]
    assert client.delete(f"/documents/{doc_id}").status_code == 204
    assert client.delete(f"/documents/{doc_id}").status_code == 404


def test_duplicate_upload_is_idempotent(client):
    data = b"# T\n\n## S\nSome unique policy text here."
    first = client.post("/documents", files={"file": ("a.md", data)}).json()
    second = client.post("/documents", files={"file": ("b.md", data)}).json()
    assert second["duplicate"] and second["id"] == first["id"]


def test_upload_validation(client):
    assert client.post("/documents", files={"file": ("x.exe", b"MZ")}).status_code == 400
    assert client.post("/documents", files={"file": ("e.txt", b"   ")}).status_code == 400
    assert client.post("/documents", files={"file": ("a.md", b"# A\n\ntext")}, data={"collection": "bad name!"}).status_code == 422


def test_pdf_upload(client):
    import io
    reportlab = __import__("pytest").importorskip("reportlab")
    from reportlab.pdfgen import canvas
    buf = io.BytesIO(); c = canvas.Canvas(buf); c.drawString(72, 720, "The office closes at 6 pm on Fridays."); c.save()
    r = client.post("/documents", files={"file": ("hours.pdf", buf.getvalue())}, data={"collection": "pdfs"})
    assert r.status_code == 201
    ans = client.post("/chat", json={"question": "When does the office close on Fridays?", "collection": "pdfs"}).json()
    assert "6 pm" in ans["answer"] and ans["citations"][0]["filename"] == "hours.pdf"


def test_chat_answers_with_citations_and_caches(client):
    q = {"question": "What is the daily meal limit when travelling?"}
    a = client.post("/chat", json=q).json()
    assert "60 USD" in a["answer"] and a["citations"][0]["filename"] == "expense-policy.md" and not a["cached"]
    b = client.post("/chat", json=q).json()
    assert b["cached"] and b["answer"] == a["answer"]


def test_cache_invalidated_when_documents_change(client):
    q = {"question": "What is the daily meal limit when travelling?"}
    client.post("/chat", json=q)
    client.post("/documents", files={"file": ("n.md", b"# N\n\n## M\nSomething unrelated about parking.")})
    assert client.post("/chat", json=q).json()["cached"] is False


def test_conversation_flow_and_feedback(client):
    first = client.post("/chat", json={"question": "How many days of annual leave do I get?"}).json()
    follow = client.post("/chat", json={"question": "and carried over?", "conversation_id": first["conversation_id"]}).json()
    assert follow["grounded"] and follow["conversation_id"] == first["conversation_id"]
    conv = client.get(f"/conversations/{first['conversation_id']}").json()
    assert [m["role"] for m in conv["messages"]] == ["user", "assistant", "user", "assistant"]
    assert client.post("/feedback", json={"message_id": follow["message_id"], "rating": 1}).status_code == 201
    assert client.post("/feedback", json={"message_id": follow["message_id"], "rating": 5}).status_code == 422
    assert client.post("/feedback", json={"message_id": "nope", "rating": 1}).status_code == 404
    assert client.post("/chat", json={"question": "hi", "conversation_id": "nope"}).status_code == 404


def test_unanswerable_question_abstains_and_is_not_cached(client):
    q = {"question": "What is the capital of Mars?"}
    a = client.post("/chat", json=q).json()
    assert a["abstained"] and not a["grounded"]
    assert client.post("/chat", json=q).json()["cached"] is False


def test_chat_validation(client):
    assert client.post("/chat", json={"question": ""}).status_code == 422
    assert client.post("/chat", json={"question": "x" * 2001}).status_code == 422


def test_api_key_required_when_configured():
    s = Services(__import__("tests.conftest", fromlist=["make_settings"]).make_settings(api_key="secret"))
    with TestClient(create_app(s.settings, s)) as c:
        assert c.get("/health").status_code == 200
        assert c.get("/documents").status_code == 401
        assert c.get("/documents", headers={"X-API-Key": "wrong"}).status_code == 401
        assert c.get("/documents", headers={"X-API-Key": "secret"}).status_code == 200
