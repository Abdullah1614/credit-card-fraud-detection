import numpy as np
import pytest

from app.retrieval.bm25 import BM25Index
from app.retrieval.embedders import HashingEmbedder
from app.retrieval.fusion import rrf
from app.retrieval.rerank import LexicalReranker
from app.stores.vector import InMemoryVectorStore, QdrantStore

import uuid


def test_bm25_ranks_matching_doc_first():
    idx = BM25Index().fit([("a", "annual leave carries over"), ("b", "expense receipts above 25 USD"), ("c", "password length")])
    assert idx.search("receipts for expenses")[0][0] == "b"
    assert idx.search("zzz unknown") == []
    assert BM25Index().search("anything") == []


def test_rrf_rewards_agreement():
    fused = rrf([["a", "b", "c"], ["c", "a", "d"]])
    assert [d for d, _ in fused][:2] == ["a", "c"]
    assert {d for d, _ in fused} == {"a", "b", "c", "d"}


def test_hashing_embedder_is_deterministic_and_normalised():
    e = HashingEmbedder(64)
    v1, v2 = e.embed(["annual leave policy"]), e.embed(["annual leave policy"])
    assert np.allclose(v1, v2) and np.isclose(np.linalg.norm(v1), 1.0)
    sim_close = float(e.embed_query("annual leave days") @ e.embed(["annual leave policy"])[0])
    sim_far = float(e.embed_query("password length") @ e.embed(["annual leave policy"])[0])
    assert sim_close > sim_far


def test_lexical_reranker_scores_relevant_higher():
    r = LexicalReranker()
    good, bad = r.rerank("meal limit while travelling", ["Meals are limited to 60 USD while travelling", "Passwords need 14 characters"])
    assert good > 0.34 > bad


@pytest.fixture(params=["memory", "qdrant"])
def store(request):
    return InMemoryVectorStore() if request.param == "memory" else QdrantStore(":memory:", dim=3)


def test_vector_store_search_filter_delete(store):
    a, b, c = (str(uuid.uuid4()) for _ in range(3))
    store.upsert("hr", [a, b], np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32))
    store.upsert("legal", [c], np.array([[1, 0, 0]], dtype=np.float32))
    hits = store.search("hr", np.array([1, 0.1, 0], dtype=np.float32), 5)
    assert hits[0][0] == a and {h[0] for h in hits} == {a, b}       # tenant filter excludes `c`
    store.delete("hr", [a])
    assert store.search("hr", np.array([1, 0, 0], dtype=np.float32), 5)[0][0] == b
    assert store.search("empty", np.array([1, 0, 0], dtype=np.float32), 5) == []
