import pytest

from app.ingestion.chunking import chunk_text

DOC = """# Policy

## Leave
Employees get 24 days.

## Expenses
Receipts are required above 25 USD.

### Meals
Meals are capped at 60 USD per day.
"""


def test_headings_are_tracked_hierarchically():
    chunks = chunk_text(DOC)
    assert [c.heading for c in chunks] == ["Policy > Leave", "Policy > Expenses", "Policy > Expenses > Meals"]
    assert "24 days" in chunks[0].text


def test_chunks_respect_size_and_overlap_long_paragraph():
    para = " ".join(f"word{i}" for i in range(400))
    chunks = chunk_text(para, size=300, overlap=50)
    assert len(chunks) > 3
    assert all(len(c.text) <= 300 for c in chunks)
    assert chunks[0].text.split()[-1] in chunks[1].text  # overlap carries context across the boundary


def test_paragraphs_pack_up_to_size():
    paras = "\n\n".join(f"Paragraph number {i} with some filler text." for i in range(30))
    chunks = chunk_text(paras, size=200, overlap=30)
    assert all(len(c.text) <= 200 + 30 + 2 for c in chunks)
    assert len(chunks) > 3


def test_all_content_survives_chunking():
    chunks = chunk_text(DOC)
    joined = " ".join(c.text for c in chunks)
    for phrase in ("24 days", "25 USD", "60 USD"):
        assert phrase in joined


def test_invalid_overlap_rejected():
    with pytest.raises(ValueError):
        chunk_text("x", size=100, overlap=100)
