from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app
from app.services import Services

ROOT = Path(__file__).resolve().parents[2]
SAMPLES = ROOT / "sample_docs"
GOLDEN = ROOT / "eval" / "golden.jsonl"


def make_settings(**overrides) -> Settings:
    base = dict(database_url="sqlite://", qdrant_url=None, redis_url=None, embedder="hashing", reranker="lexical",
                llm_provider="extractive", api_key=None)
    base.update(overrides)
    return Settings(**base)


@pytest.fixture()
def services():
    s = Services(make_settings())
    for f in sorted(SAMPLES.glob("*.md")):
        s.ingest("default", f.name, f.read_bytes())
    return s


@pytest.fixture()
def client(services):
    with TestClient(create_app(services.settings, services)) as c:
        yield c
