from app.eval.retrieval_metrics import evaluate_retrieval, load_golden
from tests.conftest import GOLDEN, SAMPLES, make_settings
from app.services import Services


def test_golden_set_retrieval_quality(services):
    report = evaluate_retrieval(services.retriever, "default", load_golden(GOLDEN), k=3)
    assert report["hit_rate@3"] >= 0.9, report["misses"]
    assert report["mrr"] >= 0.85


def test_collections_are_isolated(services):
    services.ingest("legal", "nda.md", b"# NDA\n\n## Term\nThe confidentiality term is 5 years from signing.")
    legal = services.retriever.retrieve("legal", "How long is the confidentiality term?", k=10, n=3)
    assert legal and all(r.filename == "nda.md" for r in legal)
    hr = services.retriever.retrieve("default", "How long is the confidentiality term?", k=10, n=3)
    assert all(r.filename != "nda.md" for r in hr)


def test_hybrid_results_expose_both_rankers(services):
    top = services.retriever.retrieve("default", "annual leave carried over", k=10, n=3)[0]
    assert top.bm25_rank is not None and top.dense_rank is not None and top.rerank_score > 0.34


def test_delete_removes_from_every_index(services):
    doc = next(d for d in services.repo.list_documents() if d["filename"] == "expense-policy.md")
    assert services.delete_document(doc["id"])
    after = services.retriever.retrieve("default", "meal limit while travelling", k=10, n=5)
    assert all(r.filename != "expense-policy.md" for r in after)


def test_index_rebuilds_from_database_on_restart(services):
    fresh = Services(services.settings, repo=services.repo)     # new process: empty BM25 + vector store
    top = fresh.retriever.retrieve("default", "How many days of annual leave do I get?", k=10, n=1)[0]
    assert top.filename == "employee-handbook.md"


def test_second_process_sees_documents_added_by_the_first(services):
    """Two API processes share Postgres and the vector store; each keeps its own BM25 index."""
    other = Services(services.settings, repo=services.repo, vector_store=services.vectors)
    services.ingest("default", "travel.md", b"# Travel\n\n## Visas\nBusiness visas take 10 working days to process.")
    hits = other.retriever.retrieve("default", "How long do business visas take?", k=10, n=3)
    assert hits and hits[0].filename == "travel.md"
