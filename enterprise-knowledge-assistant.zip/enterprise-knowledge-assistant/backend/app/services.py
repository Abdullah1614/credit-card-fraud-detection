"""Wires settings into concrete components and exposes the operations the API needs."""
import hashlib
from dataclasses import dataclass

from app.agent.graph import build_agent
from app.config import Settings
from app.ingestion.chunking import chunk_text
from app.ingestion.loaders import load_text
from app.llm.generators import make_generator
from app.retrieval.embedders import make_embedder
from app.retrieval.hybrid import HybridRetriever
from app.retrieval.rerank import make_reranker
from app.stores.cache import make_cache
from app.stores.db import Repo
from app.stores.vector import make_vector_store


@dataclass
class IngestResult:
    document: dict
    duplicate: bool


class Services:
    def __init__(self, settings: Settings, *, embedder=None, vector_store=None, reranker=None, generator=None,
                 cache=None, repo=None):
        self.settings = settings
        self.repo = repo or Repo(settings.database_url)
        self.embedder = embedder or make_embedder(settings)
        self.reranker = reranker or make_reranker(settings)
        self.vectors = vector_store or make_vector_store(settings, self.embedder.dim)
        self.generator = generator or make_generator(settings)
        self.cache = cache or make_cache(settings)
        self.retriever = HybridRetriever(self.repo, self.embedder, self.vectors, self.reranker)
        self.min_score = settings.rerank_min_score if settings.rerank_min_score is not None else self.reranker.default_min_score
        self.agent = build_agent(self.retriever, self.generator, settings, self.min_score)
        self.retriever.rebuild_all()

    def ingest(self, collection: str, filename: str, data: bytes) -> IngestResult:
        sha = hashlib.sha256(data).hexdigest()
        existing = self.repo.find_document(collection, sha)
        if existing:
            return IngestResult(existing, True)
        text = load_text(filename, data)
        chunks = chunk_text(text, self.settings.chunk_size, self.settings.chunk_overlap)
        if not chunks:
            raise ValueError("No text chunks could be produced from this file.")
        doc, records = self.repo.add_document(collection, filename, sha, chunks)
        self.retriever.index_document(collection, records)
        return IngestResult(doc, False)

    def delete_document(self, doc_id: str) -> bool:
        res = self.repo.delete_document(doc_id)
        if not res:
            return False
        collection, chunk_ids = res
        self.retriever.remove_chunks(collection, chunk_ids)
        return True

    def cache_key(self, collection: str, question: str) -> str:
        norm = " ".join(question.lower().split())
        raw = f"{collection}|{self.repo.collection_version(collection)}|{norm}"
        return hashlib.sha256(raw.encode()).hexdigest()
