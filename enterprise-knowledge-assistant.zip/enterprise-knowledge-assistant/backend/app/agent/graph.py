"""LangGraph agent: rewrite -> retrieve -> grade -> (generate -> verify | retry | abstain).

  START -> rewrite -> retrieve -> grade --(enough evidence)--> generate -> verify -> END
                         ^           |
                         |           +--(none, attempts left)--> rewrite (broadened)
                         |           +--(none, out of attempts)--> abstain -> END
"""
import re
from typing import TypedDict

from langgraph.graph import END, START, StateGraph

from app.llm.generators import ABSTAIN_TEXT

_CITE = re.compile(r"\[(\d+)\]")


class AgentState(TypedDict, total=False):
    question: str
    history: list[dict]
    collection: str
    query: str
    attempt: int
    candidates: list
    context: list
    answer: str
    citations: list[dict]
    grounded: bool
    abstained: bool
    trace: list[dict]


def verify_citations(answer: str, context: list) -> tuple[str, list[dict], bool]:
    """Drop citation markers that point at passages that do not exist; report whether any valid citation remains."""
    valid = set(range(1, len(context) + 1))
    answer = _CITE.sub(lambda m: m.group(0) if int(m.group(1)) in valid else "", answer)
    answer = re.sub(r"\s+([.,;])", r"\1", re.sub(r"[ ]{2,}", " ", answer)).strip()
    order: list[int] = []
    for m in _CITE.finditer(answer):
        n = int(m.group(1))
        if n not in order:
            order.append(n)
    citations = [{"index": n, "chunk_id": context[n - 1].chunk_id, "document_id": context[n - 1].document_id,
                  "filename": context[n - 1].filename, "heading": context[n - 1].heading,
                  "snippet": context[n - 1].text[:400], "score": round(context[n - 1].rerank_score, 3)} for n in order]
    return answer, citations, bool(citations)


def build_agent(retriever, generator, settings, min_score: float):
    def add(state, step: str, **info):
        return state.get("trace", []) + [{"step": step, **info}]

    def rewrite(state: AgentState):
        attempt = state.get("attempt", 0)
        base = generator.rewrite_query(state["question"], state.get("history", []))
        # On retry, search for the union of the original question and the rewrite to widen term coverage.
        query = base if attempt == 0 else f"{state['question']} {base}".strip()
        return {"query": query, "attempt": attempt, "trace": add(state, "rewrite", query=query, attempt=attempt + 1)}

    def retrieve(state: AgentState):
        widen = state.get("attempt", 0) + 1
        found = retriever.retrieve(state["collection"], state["query"], k=settings.top_k * widen, n=settings.top_n + 3)
        top = round(found[0].rerank_score, 3) if found else None
        return {"candidates": found, "trace": add(state, "retrieve", candidates=len(found), top_score=top)}

    def grade(state: AgentState):
        kept = [c for c in state.get("candidates", []) if c.rerank_score >= min_score][: settings.top_n]
        return {"context": kept, "trace": add(state, "grade", kept=len(kept), min_score=min_score)}

    def route_after_grade(state: AgentState) -> str:
        if state["context"]:
            return "generate"
        return "rewrite" if state.get("attempt", 0) + 1 < settings.max_attempts else "abstain"

    def bump(state: AgentState):
        return {"attempt": state.get("attempt", 0) + 1}

    def generate(state: AgentState):
        answer = generator.generate(state["question"], state["context"])
        return {"answer": answer, "trace": add(state, "generate", passages=len(state["context"]))}

    def verify(state: AgentState):
        answer, citations, grounded = verify_citations(state["answer"], state["context"])
        abstained = answer.strip() == ABSTAIN_TEXT
        return {"answer": answer, "citations": citations, "grounded": grounded and not abstained, "abstained": abstained,
                "trace": add(state, "verify", citations=len(citations), grounded=grounded and not abstained)}

    def abstain(state: AgentState):
        return {"answer": ABSTAIN_TEXT, "citations": [], "grounded": False, "abstained": True,
                "trace": add(state, "abstain")}

    g = StateGraph(AgentState)
    for name, fn in [("rewrite", rewrite), ("retrieve", retrieve), ("grade", grade), ("bump", bump),
                     ("generate", generate), ("verify", verify), ("abstain", abstain)]:
        g.add_node(name, fn)
    g.add_edge(START, "rewrite")
    g.add_edge("rewrite", "retrieve")
    g.add_edge("retrieve", "grade")
    g.add_conditional_edges("grade", lambda s: ("bump" if route_after_grade(s) == "rewrite" else route_after_grade(s)),
                            {"bump": "bump", "generate": "generate", "abstain": "abstain"})
    g.add_edge("bump", "rewrite")
    g.add_edge("generate", "verify")
    g.add_edge("verify", END)
    g.add_edge("abstain", END)
    compiled = g.compile()

    def run(question: str, collection: str, history: list[dict] | None = None) -> dict:
        out = compiled.invoke({"question": question, "collection": collection, "history": history or [],
                               "attempt": 0, "trace": []})
        return {"answer": out["answer"], "citations": out.get("citations", []), "grounded": out.get("grounded", False),
                "abstained": out.get("abstained", False), "trace": out["trace"], "query": out.get("query", question)}

    return run
