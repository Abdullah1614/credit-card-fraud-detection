"""Offline retrieval metrics against a golden set (no LLM needed): hit rate @k and mean reciprocal rank."""
import json
from pathlib import Path


def load_golden(path) -> list[dict]:
    return [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]


def evaluate_retrieval(retriever, collection: str, golden: list[dict], k: int = 3) -> dict:
    hits, rr, misses = 0, 0.0, []
    for g in golden:
        ranked = [r.filename for r in retriever.retrieve(collection, g["question"], k=20, n=k)]
        if g["expected_file"] in ranked:
            hits += 1
            rr += 1.0 / (ranked.index(g["expected_file"]) + 1)
        else:
            misses.append(g["question"])
    n = len(golden)
    return {f"hit_rate@{k}": hits / n, "mrr": rr / n, "n": n, "misses": misses}
