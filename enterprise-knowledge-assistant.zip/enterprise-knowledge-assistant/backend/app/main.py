"""FastAPI service for the Enterprise Knowledge Assistant.  Run: uvicorn app.main:app --reload"""
import secrets
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from app.config import Settings, get_settings
from app.services import Services

COLLECTION_PATTERN = r"^[A-Za-z0-9_-]{1,64}$"


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    collection: str = Field(default="default", pattern=COLLECTION_PATTERN)
    conversation_id: str | None = None


class FeedbackRequest(BaseModel):
    message_id: str
    rating: int = Field(description="1 = helpful, -1 = not helpful")
    comment: str | None = Field(default=None, max_length=1000)


def create_app(settings: Settings | None = None, services: Services | None = None) -> FastAPI:
    settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.svc = services or Services(settings)
        yield

    app = FastAPI(title="Enterprise Knowledge Assistant", version="1.0.0", lifespan=lifespan)
    app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
                       allow_methods=["*"], allow_headers=["*"])

    def auth(x_api_key: str | None = Header(default=None)):
        if settings.api_key and not (x_api_key and secrets.compare_digest(x_api_key, settings.api_key)):
            raise HTTPException(401, "Missing or invalid API key (send it in the X-API-Key header).")

    def svc() -> Services:
        return app.state.svc

    @app.get("/health")
    def health():
        s = svc()
        return {"status": "ok", "llm": settings.llm_provider, "embedder": settings.embedder,
                "reranker": settings.reranker, "documents": len(s.repo.list_documents())}

    @app.get("/collections", dependencies=[Depends(auth)])
    def collections():
        return {"collections": svc().repo.collections()}

    @app.post("/documents", dependencies=[Depends(auth)], status_code=201)
    async def upload(file: UploadFile = File(...), collection: str = Form("default")):
        import re
        if not re.match(COLLECTION_PATTERN, collection):
            raise HTTPException(422, "Collection may contain letters, numbers, '-' and '_' (max 64 characters).")
        data = await file.read()
        if len(data) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(413, f"File is larger than {settings.max_upload_mb} MB.")
        try:
            result = svc().ingest(collection, file.filename or "upload", data)
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        return {**result.document, "duplicate": result.duplicate}

    @app.get("/documents", dependencies=[Depends(auth)])
    def documents(collection: str | None = None):
        return {"documents": svc().repo.list_documents(collection)}

    @app.delete("/documents/{doc_id}", dependencies=[Depends(auth)], status_code=204)
    def delete_document(doc_id: str):
        if not svc().delete_document(doc_id):
            raise HTTPException(404, "Document not found.")

    @app.post("/chat", dependencies=[Depends(auth)])
    def chat(req: ChatRequest):
        s = svc()
        history: list[dict] = []
        collection = req.collection
        conv_id = req.conversation_id
        if conv_id:
            conv = s.repo.get_conversation(conv_id)
            if not conv:
                raise HTTPException(404, "Conversation not found.")
            collection = conv["collection"]
            history = s.repo.recent_messages(conv_id, 6)
        else:
            conv_id = s.repo.create_conversation(collection)

        cached = None
        key = s.cache_key(collection, req.question)
        if not history:  # follow-ups depend on history, so only stand-alone questions are cached
            cached = s.cache.get(key)
        result = cached or s.agent(req.question, collection, history)

        s.repo.add_message(conv_id, "user", req.question)
        message_id = s.repo.add_message(conv_id, "assistant", result["answer"], result["citations"], result["trace"],
                                        result["grounded"])
        if not history and not cached and result["grounded"]:
            s.cache.set(key, result, settings.cache_ttl_seconds)
        return {"conversation_id": conv_id, "message_id": message_id, "cached": bool(cached), **result}

    @app.get("/conversations/{conv_id}", dependencies=[Depends(auth)])
    def conversation(conv_id: str):
        conv = svc().repo.get_conversation(conv_id)
        if not conv:
            raise HTTPException(404, "Conversation not found.")
        return conv

    @app.post("/feedback", dependencies=[Depends(auth)], status_code=201)
    def feedback(req: FeedbackRequest):
        if req.rating not in (-1, 1):
            raise HTTPException(422, "rating must be 1 or -1")
        if not svc().repo.message_exists(req.message_id):
            raise HTTPException(404, "Message not found.")
        return {"id": svc().repo.add_feedback(req.message_id, req.rating, req.comment)}

    return app


app = create_app()
