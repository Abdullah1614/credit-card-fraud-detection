import uuid
from typing import Protocol

import numpy as np


class VectorStore(Protocol):
    persistent: bool
    def upsert(self, collection: str, ids: list[str], vectors: np.ndarray) -> None: ...
    def search(self, collection: str, vector: np.ndarray, k: int) -> list[tuple[str, float]]: ...
    def delete(self, collection: str, ids: list[str]) -> None: ...


class InMemoryVectorStore:
    """Exact cosine search with numpy. Not persistent: the retriever re-embeds from the database on startup."""
    persistent = False

    def __init__(self):
        self._ids: dict[str, list[str]] = {}
        self._mat: dict[str, np.ndarray] = {}

    def upsert(self, collection, ids, vectors):
        if not ids:
            return
        old_ids = self._ids.get(collection, [])
        old = self._mat.get(collection)
        keep = [i for i, x in enumerate(old_ids) if x not in set(ids)]
        base_ids = [old_ids[i] for i in keep]
        base = old[keep] if old is not None and keep else np.zeros((0, vectors.shape[1]), dtype=np.float32)
        self._ids[collection] = base_ids + list(ids)
        self._mat[collection] = np.vstack([base, vectors.astype(np.float32)])

    def search(self, collection, vector, k):
        mat = self._mat.get(collection)
        if mat is None or len(mat) == 0:
            return []
        sims = mat @ vector.astype(np.float32)
        top = np.argsort(-sims)[:k]
        return [(self._ids[collection][i], float(sims[i])) for i in top]

    def delete(self, collection, ids):
        drop = set(ids)
        old_ids = self._ids.get(collection, [])
        keep = [i for i, x in enumerate(old_ids) if x not in drop]
        if collection in self._mat:
            self._mat[collection] = self._mat[collection][keep]
            self._ids[collection] = [old_ids[i] for i in keep]


class QdrantStore:
    """Qdrant-backed store. One Qdrant collection holds every chunk; tenancy is a payload filter on `collection`.
    Pass url=':memory:' to use qdrant-client's local mode (used in tests)."""
    persistent = True
    NAME = "chunks"

    def __init__(self, url: str, dim: int):
        from qdrant_client import QdrantClient, models
        self._m = models
        self._client = QdrantClient(location=":memory:") if url == ":memory:" else QdrantClient(url=url)
        existing = {c.name for c in self._client.get_collections().collections}
        if self.NAME not in existing:
            self._client.create_collection(
                self.NAME, vectors_config=models.VectorParams(size=dim, distance=models.Distance.COSINE))
            self._client.create_payload_index(self.NAME, "collection", models.PayloadSchemaType.KEYWORD)

    @staticmethod
    def _pid(chunk_id: str) -> str:
        return str(uuid.UUID(chunk_id))

    def upsert(self, collection, ids, vectors):
        if not ids:
            return
        pts = [self._m.PointStruct(id=self._pid(i), vector=v.tolist(), payload={"collection": collection, "chunk_id": i})
               for i, v in zip(ids, vectors)]
        self._client.upsert(self.NAME, points=pts)

    def _filter(self, collection):
        return self._m.Filter(must=[self._m.FieldCondition(key="collection", match=self._m.MatchValue(value=collection))])

    def search(self, collection, vector, k):
        res = self._client.query_points(
            self.NAME, query=vector.tolist(), limit=k, query_filter=self._filter(collection), with_payload=True)
        return [(p.payload["chunk_id"], float(p.score)) for p in res.points]

    def delete(self, collection, ids):
        if ids:
            self._client.delete(self.NAME, points_selector=self._m.PointIdsList(points=[self._pid(i) for i in ids]))


def make_vector_store(settings, dim: int) -> VectorStore:
    return QdrantStore(settings.qdrant_url, dim) if settings.qdrant_url else InMemoryVectorStore()
