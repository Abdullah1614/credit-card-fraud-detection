import json
import time
from typing import Protocol


class Cache(Protocol):
    def get(self, key: str) -> dict | None: ...
    def set(self, key: str, value: dict, ttl: int) -> None: ...


class InMemoryCache:
    def __init__(self):
        self._d: dict[str, tuple[float, str]] = {}

    def get(self, key):
        item = self._d.get(key)
        if not item:
            return None
        expires, raw = item
        if expires < time.time():
            self._d.pop(key, None)
            return None
        return json.loads(raw)

    def set(self, key, value, ttl):
        self._d[key] = (time.time() + ttl, json.dumps(value))


class RedisCache:
    def __init__(self, url: str):
        import redis
        self._r = redis.Redis.from_url(url, socket_timeout=2)

    def get(self, key):
        try:
            raw = self._r.get(f"eka:{key}")
        except Exception:  # a cache outage must never break answering
            return None
        return json.loads(raw) if raw else None

    def set(self, key, value, ttl):
        try:
            self._r.setex(f"eka:{key}", ttl, json.dumps(value))
        except Exception:
            pass


def make_cache(settings) -> Cache:
    return RedisCache(settings.redis_url) if settings.redis_url else InMemoryCache()
