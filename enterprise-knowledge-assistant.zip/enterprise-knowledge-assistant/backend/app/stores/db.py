"""Relational store (PostgreSQL in production, SQLite for dev/tests). Chunks live here as the source of truth;
vectors live in the vector store and the BM25 index is rebuilt from these rows."""
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text, create_engine, delete, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy.pool import StaticPool


def _uid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Document(Base):
    __tablename__ = "documents"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uid)
    collection: Mapped[str] = mapped_column(String(64), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    sha256: Mapped[str] = mapped_column(String(64))
    n_chunks: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Chunk(Base):
    __tablename__ = "chunks"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uid)
    document_id: Mapped[str] = mapped_column(String(36), ForeignKey("documents.id"), index=True)
    collection: Mapped[str] = mapped_column(String(64), index=True)
    ordinal: Mapped[int] = mapped_column(Integer)
    heading: Mapped[str] = mapped_column(Text, default="")
    text: Mapped[str] = mapped_column(Text)


class Conversation(Base):
    __tablename__ = "conversations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uid)
    collection: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Message(Base):
    __tablename__ = "messages"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uid)
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), index=True)
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str] = mapped_column(Text)
    citations: Mapped[list] = mapped_column(JSON, default=list)
    trace: Mapped[list] = mapped_column(JSON, default=list)
    grounded: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Feedback(Base):
    __tablename__ = "feedback"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uid)
    message_id: Mapped[str] = mapped_column(String(36), ForeignKey("messages.id"), index=True)
    rating: Mapped[int] = mapped_column(Integer)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


@dataclass
class ChunkRecord:
    id: str
    document_id: str
    filename: str
    collection: str
    ordinal: int
    heading: str
    text: str

    @property
    def index_text(self) -> str:
        return f"{self.heading}\n{self.text}" if self.heading else self.text


def _doc_dict(d: Document) -> dict:
    return {"id": d.id, "collection": d.collection, "filename": d.filename, "n_chunks": d.n_chunks,
            "created_at": d.created_at.isoformat()}


class Repo:
    def __init__(self, url: str):
        kwargs = {}
        if url.startswith("sqlite"):
            kwargs["connect_args"] = {"check_same_thread": False}
            if url in ("sqlite://", "sqlite:///:memory:"):
                kwargs["poolclass"] = StaticPool
        self.engine = create_engine(url, **kwargs)
        Base.metadata.create_all(self.engine)
        self._S = sessionmaker(self.engine, expire_on_commit=False)

    # ---- documents -------------------------------------------------------------------------------------
    def find_document(self, collection: str, sha256: str) -> dict | None:
        with self._S() as s:
            d = s.scalars(select(Document).where(Document.collection == collection, Document.sha256 == sha256)).first()
            return _doc_dict(d) if d else None

    def add_document(self, collection, filename, sha256, chunks) -> tuple[dict, list[ChunkRecord]]:
        with self._S() as s:
            doc = Document(collection=collection, filename=filename, sha256=sha256, n_chunks=len(chunks))
            s.add(doc); s.flush()
            rows = [Chunk(document_id=doc.id, collection=collection, ordinal=i, heading=c.heading, text=c.text)
                    for i, c in enumerate(chunks)]
            s.add_all(rows); s.commit()
            recs = [ChunkRecord(r.id, doc.id, filename, collection, r.ordinal, r.heading, r.text) for r in rows]
            return _doc_dict(doc), recs

    def list_documents(self, collection: str | None = None) -> list[dict]:
        with self._S() as s:
            q = select(Document).order_by(Document.created_at.desc())
            if collection:
                q = q.where(Document.collection == collection)
            return [_doc_dict(d) for d in s.scalars(q)]

    def delete_document(self, doc_id: str) -> tuple[str, list[str]] | None:
        with self._S() as s:
            doc = s.get(Document, doc_id)
            if not doc:
                return None
            ids = list(s.scalars(select(Chunk.id).where(Chunk.document_id == doc_id)))
            s.execute(delete(Chunk).where(Chunk.document_id == doc_id))
            s.delete(doc); s.commit()
            return doc.collection, ids

    def collections(self) -> list[str]:
        with self._S() as s:
            return sorted(s.scalars(select(Document.collection).distinct()))

    def collection_version(self, collection: str) -> str:
        """Changes whenever documents are added or removed; used to invalidate cached answers."""
        with self._S() as s:
            n, last = s.execute(select(func.count(Document.id), func.max(Document.created_at))
                                .where(Document.collection == collection)).one()
            return f"{n}:{last.isoformat() if last else '-'}"

    # ---- chunks ----------------------------------------------------------------------------------------
    def _records(self, s, q) -> list[ChunkRecord]:
        rows = s.execute(q.add_columns(Document.filename).join(Document, Document.id == Chunk.document_id)).all()
        return [ChunkRecord(c.id, c.document_id, fn, c.collection, c.ordinal, c.heading, c.text) for c, fn in rows]

    def all_chunks(self, collection: str | None = None) -> list[ChunkRecord]:
        with self._S() as s:
            q = select(Chunk).order_by(Chunk.document_id, Chunk.ordinal)
            if collection:
                q = q.where(Chunk.collection == collection)
            return self._records(s, q)

    def get_chunks(self, ids: list[str]) -> dict[str, ChunkRecord]:
        if not ids:
            return {}
        with self._S() as s:
            return {r.id: r for r in self._records(s, select(Chunk).where(Chunk.id.in_(ids)))}

    # ---- conversations ---------------------------------------------------------------------------------
    def create_conversation(self, collection: str) -> str:
        with self._S() as s:
            c = Conversation(collection=collection)
            s.add(c); s.commit()
            return c.id

    def get_conversation(self, conv_id: str) -> dict | None:
        with self._S() as s:
            c = s.get(Conversation, conv_id)
            if not c:
                return None
            msgs = s.scalars(select(Message).where(Message.conversation_id == conv_id).order_by(Message.created_at, Message.id))
            return {"id": c.id, "collection": c.collection, "messages": [
                {"id": m.id, "role": m.role, "content": m.content, "citations": m.citations, "grounded": m.grounded,
                 "created_at": m.created_at.isoformat()} for m in msgs]}

    def add_message(self, conv_id, role, content, citations=None, trace=None, grounded=True) -> str:
        with self._S() as s:
            m = Message(conversation_id=conv_id, role=role, content=content, citations=citations or [],
                        trace=trace or [], grounded=grounded)
            s.add(m); s.commit()
            return m.id

    def recent_messages(self, conv_id: str, n: int = 6) -> list[dict]:
        with self._S() as s:
            rows = list(s.scalars(select(Message).where(Message.conversation_id == conv_id)
                                  .order_by(Message.created_at.desc(), Message.id.desc()).limit(n)))
            return [{"role": m.role, "content": m.content} for m in reversed(rows)]

    def message_exists(self, message_id: str) -> bool:
        with self._S() as s:
            return s.get(Message, message_id) is not None

    def add_feedback(self, message_id: str, rating: int, comment: str | None) -> str:
        with self._S() as s:
            f = Feedback(message_id=message_id, rating=rating, comment=comment)
            s.add(f); s.commit()
            return f.id
