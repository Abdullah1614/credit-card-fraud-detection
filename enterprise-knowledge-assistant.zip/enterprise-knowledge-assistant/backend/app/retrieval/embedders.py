import hashlib
from typing import Protocol

import numpy as np

from .tokenize import tokenize


class Embedder(Protocol):
    dim: int
    def embed(self, texts: list[str]) -> np.ndarray: ...
    def embed_query(self, text: str) -> np.ndarray: ...


class HashingEmbedder:
    """Deterministic bag-of-words (+ bigrams) hashing embedder. Offline and dependency-free, for tests and
    development. It matches on shared words, not meaning; use FastEmbedEmbedder for semantic search."""

    def __init__(self, dim: int = 384):
        self.dim = dim

    def _vec(self, text: str) -> np.ndarray:
        v = np.zeros(self.dim, dtype=np.float32)
        toks = tokenize(text)
        feats = toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])]
        for f in feats:
            h = int.from_bytes(hashlib.blake2b(f.encode(), digest_size=8).digest(), "little")
            v[h % self.dim] += 1.0 if (h >> 63) & 1 else -1.0
        n = np.linalg.norm(v)
        return v / n if n else v

    def embed(self, texts):
        return np.vstack([self._vec(t) for t in texts]) if texts else np.zeros((0, self.dim), dtype=np.float32)

    def embed_query(self, text):
        return self._vec(text)


class FastEmbedEmbedder:
    """ONNX sentence embeddings via fastembed (no PyTorch). Downloads the model on first use."""

    def __init__(self, model: str = "BAAI/bge-small-en-v1.5"):
        from fastembed import TextEmbedding
        self._model = TextEmbedding(model_name=model)
        self.dim = len(next(iter(self._model.embed(["dimension probe"]))))

    def embed(self, texts):
        if not texts:
            return np.zeros((0, self.dim), dtype=np.float32)
        return np.asarray(list(self._model.embed(texts)), dtype=np.float32)

    def embed_query(self, text):
        return np.asarray(next(iter(self._model.query_embed(text))), dtype=np.float32)


def make_embedder(settings) -> Embedder:
    if settings.embedder == "fastembed":
        return FastEmbedEmbedder(settings.embedding_model)
    if settings.embedder == "hashing":
        return HashingEmbedder(settings.embedding_dim)
    raise ValueError(f"Unknown EMBEDDER '{settings.embedder}' (use 'hashing' or 'fastembed')")
