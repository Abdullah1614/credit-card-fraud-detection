import threading
from dataclasses import asdict, dataclass

from .bm25 import BM25Index
from .fusion import rrf


@dataclass
class Retrieved:
    chunk_id: str
    document_id: str
    filename: str
    heading: str
    text: str
    bm25_rank: int | None
    dense_rank: int | None
    fused_score: float
    rerank_score: float

    def to_dict(self) -> dict:
        return asdict(self)


class HybridRetriever:
    """BM25 + dense vectors, fused with Reciprocal Rank Fusion, then reranked.

    Pipeline per query: (1) BM25 top-k  (2) vector top-k  (3) RRF merge  (4) rerank merged candidates
    with the reranker (a cross-encoder in production) and return the top n.
    """

    def __init__(self, repo, embedder, vector_store, reranker, rrf_k: int = 60):
        self.repo, self.embedder, self.vectors, self.reranker, self.rrf_k = repo, embedder, vector_store, reranker, rrf_k
        self._bm25: dict[str, BM25Index] = {}
        self._versions: dict[str, str] = {}
        self._lock = threading.RLock()

    def _rebuild_bm25(self, collection: str) -> None:
        version = self.repo.collection_version(collection)
        recs = self.repo.all_chunks(collection)
        self._bm25[collection] = BM25Index().fit([(r.id, r.index_text) for r in recs])
        self._versions[collection] = version

    def _fresh_bm25(self, collection: str) -> BM25Index | None:
        """The BM25 index lives in this process; if another process changed the collection, rebuild it."""
        version = self.repo.collection_version(collection)
        if self._versions.get(collection) != version:
            with self._lock:
                if self._versions.get(collection) != version:
                    self._rebuild_bm25(collection)
        return self._bm25.get(collection)

    def index_document(self, collection: str, records) -> None:
        vecs = self.embedder.embed([r.index_text for r in records])
        with self._lock:
            self.vectors.upsert(collection, [r.id for r in records], vecs)
            self._rebuild_bm25(collection)

    def remove_chunks(self, collection: str, chunk_ids: list[str]) -> None:
        with self._lock:
            self.vectors.delete(collection, chunk_ids)
            self._rebuild_bm25(collection)

    def rebuild_all(self, batch: int = 64) -> None:
        """Called at startup: BM25 is always rebuilt; vectors only if the store does not persist them."""
        with self._lock:
            by_col: dict[str, list] = {}
            for r in self.repo.all_chunks():
                by_col.setdefault(r.collection, []).append(r)
            for col, recs in by_col.items():
                self._rebuild_bm25(col)
                if not self.vectors.persistent:
                    for i in range(0, len(recs), batch):
                        part = recs[i:i + batch]
                        self.vectors.upsert(col, [r.id for r in part], self.embedder.embed([r.index_text for r in part]))

    def retrieve(self, collection: str, query: str, k: int = 20, n: int = 5) -> list[Retrieved]:
        bm = self._fresh_bm25(collection)
        sparse = bm.search(query, k) if bm else []
        dense = self.vectors.search(collection, self.embedder.embed_query(query), k)
        sparse_rank = {cid: i for i, (cid, _) in enumerate(sparse, 1)}
        dense_rank = {cid: i for i, (cid, _) in enumerate(dense, 1)}
        fused = rrf([[c for c, _ in sparse], [c for c, _ in dense]], self.rrf_k)[:k]
        recs = self.repo.get_chunks([c for c, _ in fused])
        fused = [(c, s) for c, s in fused if c in recs]
        if not fused:
            return []
        scores = self.reranker.rerank(query, [recs[c].index_text for c, _ in fused])
        out = [Retrieved(c, recs[c].document_id, recs[c].filename, recs[c].heading, recs[c].text,
                         sparse_rank.get(c), dense_rank.get(c), fs, float(rs))
               for (c, fs), rs in zip(fused, scores)]
        out.sort(key=lambda r: (r.rerank_score, r.fused_score), reverse=True)
        return out[:n]
