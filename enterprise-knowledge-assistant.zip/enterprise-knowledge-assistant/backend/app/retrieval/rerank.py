import math
from typing import Protocol

from .tokenize import tokenize


class Reranker(Protocol):
    default_min_score: float
    def rerank(self, query: str, passages: list[str]) -> list[float]: ...


class LexicalReranker:
    """Offline stand-in: query-term coverage plus a bigram bonus, in [0, 1]. Use the cross-encoder in production."""
    default_min_score = 0.34

    def rerank(self, query, passages):
        q = tokenize(query)
        if not q:
            return [0.0] * len(passages)
        qset, qbi = set(q), set(zip(q, q[1:]))
        out = []
        for p in passages:
            pt = tokenize(p)
            pset, pbi = set(pt), set(zip(pt, pt[1:]))
            cov = len(qset & pset) / len(qset)
            bi = (len(qbi & pbi) / len(qbi)) if qbi else cov
            out.append(min(1.0, 0.8 * cov + 0.2 * bi))
        return out


class FastEmbedReranker:
    """Cross-encoder reranker (ms-marco MiniLM via fastembed). Logits are squashed to (0, 1)."""
    default_min_score = 0.2

    def __init__(self, model: str = "Xenova/ms-marco-MiniLM-L-6-v2"):
        from fastembed.rerank.cross_encoder import TextCrossEncoder
        self._model = TextCrossEncoder(model_name=model)

    def rerank(self, query, passages):
        if not passages:
            return []
        return [1.0 / (1.0 + math.exp(-float(s))) for s in self._model.rerank(query, passages)]


def make_reranker(settings) -> Reranker:
    if settings.reranker == "fastembed":
        return FastEmbedReranker(settings.rerank_model)
    if settings.reranker == "lexical":
        return LexicalReranker()
    raise ValueError(f"Unknown RERANKER '{settings.reranker}' (use 'lexical' or 'fastembed')")
