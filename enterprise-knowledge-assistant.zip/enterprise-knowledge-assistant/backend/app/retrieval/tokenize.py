import re

STOPWORDS = frozenset("""a an and are as at be been by can could do does did for from get had has have how i if in into is it its
me my of on or our so than that the their them then there these they this to us was we were what when where which who whom
why will with would you your many much about should""".split())

_TOKEN = re.compile(r"\w+", re.UNICODE)


def stem(tok: str) -> str:
    if len(tok) > 4 and tok.endswith("ies"):
        return tok[:-3] + "y"
    if len(tok) > 3 and tok.endswith("s") and not tok.endswith("ss"):
        return tok[:-1]
    return tok


def tokenize(text: str, drop_stopwords: bool = True) -> list[str]:
    toks = _TOKEN.findall(text.lower())
    if drop_stopwords:
        toks = [t for t in toks if t not in STOPWORDS]
    return [stem(t) for t in toks]
