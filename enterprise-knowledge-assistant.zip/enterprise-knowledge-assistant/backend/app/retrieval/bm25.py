import math
from collections import Counter, defaultdict

from .tokenize import tokenize


class BM25Index:
    """Okapi BM25 over a small in-process corpus (one index per collection)."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self._ids: list[str] = []
        self._len: list[int] = []
        self._postings: dict[str, list[tuple[int, int]]] = defaultdict(list)
        self._avgdl = 0.0

    def fit(self, docs: list[tuple[str, str]]) -> "BM25Index":
        self._ids = [d[0] for d in docs]
        self._postings = defaultdict(list)
        self._len = []
        for i, (_, text) in enumerate(docs):
            toks = tokenize(text)
            self._len.append(len(toks))
            for term, tf in Counter(toks).items():
                self._postings[term].append((i, tf))
        self._avgdl = (sum(self._len) / len(self._len)) if self._len else 0.0
        return self

    def __len__(self) -> int:
        return len(self._ids)

    def search(self, query: str, k: int = 20) -> list[tuple[str, float]]:
        n = len(self._ids)
        if n == 0:
            return []
        scores: dict[int, float] = defaultdict(float)
        for term in set(tokenize(query)):
            postings = self._postings.get(term)
            if not postings:
                continue
            idf = math.log(1 + (n - len(postings) + 0.5) / (len(postings) + 0.5))
            for i, tf in postings:
                norm = self.k1 * (1 - self.b + self.b * self._len[i] / (self._avgdl or 1.0))
                scores[i] += idf * tf * (self.k1 + 1) / (tf + norm)
        ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:k]
        return [(self._ids[i], s) for i, s in ranked]
