"""Configuration from environment variables. Defaults run fully offline (no API keys, no services)."""
import os
from dataclasses import dataclass, field
from functools import lru_cache


def _env(name: str, default=None):
    v = os.getenv(name)
    return default if v in (None, "") else v


@dataclass(frozen=True)
class Settings:
    # infrastructure (unset = in-process fallback, suitable for dev and tests)
    database_url: str = field(default_factory=lambda: _env("DATABASE_URL", "sqlite:///./data/app.db"))
    qdrant_url: str | None = field(default_factory=lambda: _env("QDRANT_URL"))
    redis_url: str | None = field(default_factory=lambda: _env("REDIS_URL"))
    # models: "hashing"/"lexical"/"extractive" work offline; "fastembed"/"anthropic" are the real ones
    embedder: str = field(default_factory=lambda: _env("EMBEDDER", "hashing"))
    reranker: str = field(default_factory=lambda: _env("RERANKER", "lexical"))
    llm_provider: str = field(default_factory=lambda: _env("LLM_PROVIDER", "extractive"))
    anthropic_model: str = field(default_factory=lambda: _env("ANTHROPIC_MODEL", "claude-sonnet-5-5"))
    embedding_model: str = field(default_factory=lambda: _env("EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5"))
    rerank_model: str = field(default_factory=lambda: _env("RERANK_MODEL", "Xenova/ms-marco-MiniLM-L-6-v2"))
    embedding_dim: int = field(default_factory=lambda: int(_env("EMBEDDING_DIM", "384")))
    # retrieval and agent
    top_k: int = field(default_factory=lambda: int(_env("TOP_K", "20")))
    top_n: int = field(default_factory=lambda: int(_env("TOP_N", "5")))
    rerank_min_score: float | None = field(default_factory=lambda: float(_env("RERANK_MIN_SCORE")) if _env("RERANK_MIN_SCORE") else None)
    max_attempts: int = field(default_factory=lambda: int(_env("MAX_ATTEMPTS", "2")))
    # ingestion
    chunk_size: int = field(default_factory=lambda: int(_env("CHUNK_SIZE", "900")))
    chunk_overlap: int = field(default_factory=lambda: int(_env("CHUNK_OVERLAP", "150")))
    max_upload_mb: int = field(default_factory=lambda: int(_env("MAX_UPLOAD_MB", "10")))
    # service
    api_key: str | None = field(default_factory=lambda: _env("API_KEY"))
    cache_ttl_seconds: int = field(default_factory=lambda: int(_env("CACHE_TTL_SECONDS", "3600")))
    cors_origins: str = field(default_factory=lambda: _env("CORS_ORIGINS", "http://localhost:3000"))


@lru_cache
def get_settings() -> Settings:
    return Settings()
