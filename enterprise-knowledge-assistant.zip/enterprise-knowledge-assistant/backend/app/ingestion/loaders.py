import io
from pathlib import Path

SUPPORTED = {".txt", ".md", ".pdf"}


def load_text(filename: str, data: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED:
        raise ValueError(f"Unsupported file type '{ext}'. Supported: {', '.join(sorted(SUPPORTED))}")
    if ext == ".pdf":
        from pypdf import PdfReader
        try:
            reader = PdfReader(io.BytesIO(data))
            pages = [(p.extract_text() or "").strip() for p in reader.pages]
        except Exception as exc:  # corrupt or encrypted PDFs
            raise ValueError(f"Could not read PDF: {exc}") from exc
        text = "\n\n".join(p for p in pages if p)
    else:
        text = data.decode("utf-8", errors="replace")
    text = text.replace("\r\n", "\n").strip()
    if not text:
        raise ValueError("The file contains no extractable text (scanned PDFs need OCR first).")
    return text
