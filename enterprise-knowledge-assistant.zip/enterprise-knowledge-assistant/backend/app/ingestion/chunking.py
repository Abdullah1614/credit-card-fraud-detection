"""Heading-aware chunking. Each chunk keeps the heading it came from, which is indexed with the text
so that a paragraph like "Receipts are required..." stays tied to its section ("Expense Policy > Receipts")."""
import re
from dataclasses import dataclass

_HEADING = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")


@dataclass
class ChunkOut:
    heading: str
    text: str


def _sections(text: str) -> list[tuple[str, str]]:
    stack: list[tuple[int, str]] = []
    sections: list[tuple[str, list[str]]] = [("", [])]
    for line in text.split("\n"):
        m = _HEADING.match(line)
        if m:
            level, title = len(m.group(1)), m.group(2)
            stack = [(l, t) for l, t in stack if l < level] + [(level, title)]
            sections.append((" > ".join(t for _, t in stack), []))
        else:
            sections[-1][1].append(line)
    return [(h, "\n".join(b).strip()) for h, b in sections if "\n".join(b).strip()]


def _tail(s: str, n: int) -> str:
    if n <= 0:
        return ""
    if len(s) <= n:
        return s
    cut = s[-n:]
    space = cut.find(" ")
    return cut[space + 1:] if space != -1 else cut


def _windows(p: str, size: int, overlap: int) -> list[str]:
    out, start = [], 0
    while start < len(p):
        end = min(start + size, len(p))
        if end < len(p):
            space = p.rfind(" ", start + size // 2, end)
            end = space if space != -1 else end
        out.append(p[start:end].strip())
        if end >= len(p):
            break
        start = max(end - overlap, start + 1)
    return [w for w in out if w]


def chunk_text(text: str, size: int = 900, overlap: int = 150) -> list[ChunkOut]:
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")
    chunks: list[ChunkOut] = []
    for heading, body in _sections(text):
        buf = ""
        for para in (p.strip() for p in re.split(r"\n\s*\n", body)):
            if not para:
                continue
            if len(para) > size:
                if buf:
                    chunks.append(ChunkOut(heading, buf)); buf = ""
                chunks.extend(ChunkOut(heading, w) for w in _windows(para, size, overlap))
            elif buf and len(buf) + len(para) + 2 > size:
                chunks.append(ChunkOut(heading, buf))
                buf = f"{_tail(buf, overlap)}\n\n{para}".strip()
            else:
                buf = f"{buf}\n\n{para}" if buf else para
        if buf:
            chunks.append(ChunkOut(heading, buf))
    return chunks
