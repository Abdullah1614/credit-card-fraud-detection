"""End-to-end answer-quality evaluation with RAGAS (faithfulness, answer relevancy, context precision/recall).

NOT RUN in this repository's test environment: it needs an Anthropic API key and downloads embedding models, and
RAGAS / LangChain APIs change between releases. Install `requirements-eval.txt` in a clean virtualenv, and if an
import fails, check the RAGAS docs for the current names of the metrics and wrappers.

    ANTHROPIC_API_KEY=... LLM_PROVIDER=anthropic EMBEDDER=fastembed RERANKER=fastembed \
        python -m scripts.eval_ragas
"""
import json
import os
from pathlib import Path

from app.config import Settings
from app.eval.retrieval_metrics import load_golden
from app.services import Services

ROOT = Path(__file__).resolve().parents[2]


def main():
    from langchain_anthropic import ChatAnthropic
    from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
    from ragas import EvaluationDataset, evaluate
    from ragas.embeddings import LangchainEmbeddingsWrapper
    from ragas.llms import LangchainLLMWrapper
    from ragas.metrics import Faithfulness, LLMContextPrecisionWithReference, LLMContextRecall, ResponseRelevancy

    settings = Settings(database_url="sqlite://", qdrant_url=None, redis_url=None)
    svc = Services(settings)
    for f in sorted((ROOT / "sample_docs").glob("*.md")):
        svc.ingest("eval", f.name, f.read_bytes())

    rows = []
    for g in load_golden(ROOT / "eval" / "golden.jsonl"):
        out = svc.agent(g["question"], "eval")
        rows.append({
            "user_input": g["question"],
            "response": out["answer"],
            "retrieved_contexts": [c["snippet"] for c in out["citations"]]
            or [r.text for r in svc.retriever.retrieve("eval", g["question"], k=20, n=3)],
            "reference": g["ground_truth"],
        })

    judge = LangchainLLMWrapper(ChatAnthropic(model=settings.anthropic_model, temperature=0))
    emb = LangchainEmbeddingsWrapper(FastEmbedEmbeddings(model_name=settings.embedding_model))
    result = evaluate(EvaluationDataset.from_list(rows),
                      metrics=[Faithfulness(), ResponseRelevancy(), LLMContextPrecisionWithReference(), LLMContextRecall()],
                      llm=judge, embeddings=emb)
    df = result.to_pandas()
    print(df.mean(numeric_only=True).round(3).to_string())
    out_dir = ROOT / "eval" / "results"
    out_dir.mkdir(exist_ok=True)
    df.to_csv(out_dir / "ragas_scores.csv", index=False)
    (out_dir / "ragas_summary.json").write_text(json.dumps(df.mean(numeric_only=True).round(4).to_dict(), indent=2))


if __name__ == "__main__":
    assert os.getenv("ANTHROPIC_API_KEY"), "Set ANTHROPIC_API_KEY to run the RAGAS judge."
    main()
