"""Offline retrieval evaluation (hit rate@k, MRR) on the golden set. No LLM or API key needed.

    python -m scripts.eval_retrieval                      # uses the env config (EMBEDDER, RERANKER, ...)
    EMBEDDER=fastembed RERANKER=fastembed python -m scripts.eval_retrieval
"""
import json
import sys
from pathlib import Path

from app.config import Settings
from app.eval.retrieval_metrics import evaluate_retrieval, load_golden
from app.services import Services

ROOT = Path(__file__).resolve().parents[2]


def main(k: int = 3):
    s = Settings(database_url="sqlite://", qdrant_url=None, redis_url=None)
    svc = Services(s)
    for f in sorted((ROOT / "sample_docs").glob("*.md")):
        svc.ingest("eval", f.name, f.read_bytes())
    report = evaluate_retrieval(svc.retriever, "eval", load_golden(ROOT / "eval" / "golden.jsonl"), k=k)
    print(json.dumps({"embedder": s.embedder, "reranker": s.reranker, **report}, indent=2))


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 3)
