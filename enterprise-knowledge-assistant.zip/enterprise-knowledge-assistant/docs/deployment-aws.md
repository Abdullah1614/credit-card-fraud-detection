# Deploying to AWS (reference design, not executed in this repository)

| Component | AWS service | Notes |
|---|---|---|
| Frontend (Next.js) | ECS Fargate service behind an Application Load Balancer | Set `BACKEND_URL` to the backend's internal service address and `API_KEY` from Secrets Manager. |
| Backend (FastAPI) | ECS Fargate service (2+ tasks is safe: each task rebuilds its BM25 index when the collection changes) | Needs ~2 GB RAM with the fastembed models loaded. Mount an EFS volume at `/home/appuser/.cache` so models are not re-downloaded per task. |
| PostgreSQL | RDS for PostgreSQL | `DATABASE_URL=postgresql+psycopg://user:pass@host:5432/db`. Tables are created on startup. |
| Redis | ElastiCache for Redis | `REDIS_URL=redis://host:6379/0`. A cache outage degrades to uncached answers; it never fails a request. |
| Qdrant | Qdrant Cloud, or a single EC2/ECS task with EBS storage | `QDRANT_URL=https://...`. Vectors are the one stateful piece outside Postgres. |
| Secrets | Secrets Manager | `ANTHROPIC_API_KEY`, `API_KEY`, database password. |
| Images | ECR | Built from `backend/Dockerfile` and `frontend/Dockerfile`. |

## Steps
1. Create the ECR repositories, push both images, and create an ECS cluster.
2. Provision RDS, ElastiCache and Qdrant in private subnets; allow the backend task security group to reach them.
3. Create task definitions with the environment variables above (`EMBEDDER=fastembed`, `RERANKER=fastembed`, `LLM_PROVIDER=anthropic`).
4. Expose only the frontend through the ALB; keep the backend internal so the API key stays server-side.
5. Add a CI deploy job (OIDC role to ECR, then `aws ecs update-service --force-new-deployment`).

## Before calling this "deployed"
Run the stack against real documents, check `/health`, and measure latency and answer quality with `scripts/eval_ragas.py`.
Known gaps for production: no per-user authentication or per-document access control (access is by collection and one shared key),
no rate limiting, and the BM25 index is held in each backend process's memory (rebuilt from Postgres on start and whenever the collection changes), which will not scale to very large collections; move it to Postgres full-text search or Qdrant sparse vectors.
