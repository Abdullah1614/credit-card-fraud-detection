# Information Security Policy

## Passwords and Authentication
Passwords must be at least 14 characters. Multi-factor authentication is mandatory for all company systems. Passwords are rotated only on suspected compromise.

## Device Security
Laptops must use full-disk encryption and lock automatically after 5 minutes of inactivity. Personal devices may not store customer data.

## Incident Reporting
Report suspected security incidents to the security team at security@northwind.example within 1 hour of discovery. Do not attempt to investigate on your own.

## Data Classification
Data is classified as Public, Internal, Confidential or Restricted. Customer personal data is Restricted and must be encrypted at rest and in transit.
