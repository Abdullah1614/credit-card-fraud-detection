# Expense Policy

## Eligible Expenses
Business travel, client meals, software subscriptions and conference fees are reimbursable when approved in advance by a manager.

## Receipts and Limits
Receipts are required for every expense above 25 USD. Meals are limited to 60 USD per person per day while travelling. Hotel stays must be booked through the corporate travel portal, with a nightly limit of 220 USD.

## Submission Deadline
Expense reports must be submitted within 30 days of the purchase. Reports older than 60 days will not be reimbursed. Reimbursement is paid with the next payroll cycle.

## Approvals
Expenses above 1,000 USD require approval from a director. Expenses above 10,000 USD require approval from the CFO.
