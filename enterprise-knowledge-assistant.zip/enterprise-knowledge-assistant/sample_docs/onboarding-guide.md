# New Hire Onboarding

## First Week
New hires receive a laptop on day one and complete security training within the first 5 days. Your buddy schedules daily check-ins during the first week.

## Benefits Enrolment
Health insurance enrolment must be completed within 30 days of the start date. Coverage begins on the first day of the month after enrolment.

## Probation Period
The probation period lasts 90 days, with a formal review at day 45 and day 85.

## Learning Budget
Each employee has an annual learning budget of 1,500 USD for courses, books and conferences, approved by their manager.
