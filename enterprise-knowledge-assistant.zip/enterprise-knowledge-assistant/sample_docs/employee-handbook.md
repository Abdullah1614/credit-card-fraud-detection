# Employee Handbook

## Annual Leave
Full-time employees receive 24 days of paid annual leave per calendar year. Leave accrues monthly. Up to 5 unused days may be carried over into the next year; carried-over days expire on 31 March.

## Sick Leave
Employees receive 10 paid sick days per year. A medical certificate is required for absences longer than 3 consecutive days.

## Parental Leave
Primary caregivers receive 16 weeks of fully paid parental leave. Secondary caregivers receive 6 weeks.

## Remote Work
Employees may work remotely up to 3 days per week with manager approval. Core collaboration hours are 10:00 to 15:00 in the employee's local time. Fully remote arrangements require approval from the department head.
