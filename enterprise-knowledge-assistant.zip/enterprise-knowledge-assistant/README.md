# AI Enterprise Knowledge Assistant

A retrieval-augmented question-answering system for company documents. Users upload PDFs, Markdown or text files into
named collections and ask questions in a chat UI. Every answer is written from retrieved passages, carries numbered
citations that open the source text, and the system declines to answer when it finds no evidence.

**Stack:** Next.js (React, TypeScript) · FastAPI · LangGraph · hybrid retrieval (BM25 + dense vectors, Reciprocal Rank
Fusion, cross-encoder reranking) · PostgreSQL · Redis · Qdrant · Claude (Anthropic API) · RAGAS · Docker · AWS (reference design)

```mermaid
flowchart LR
  UI[Next.js UI] -->|/api proxy, API key stays server-side| API[FastAPI]
  API --> AG[LangGraph agent]
  AG --> R[Hybrid retriever]
  R --> BM[BM25 index]
  R --> QD[(Qdrant vectors)]
  R --> RR[Cross-encoder reranker]
  AG --> LLM[Claude]
  API --> PG[(PostgreSQL: documents, chunks, chats, feedback)]
  API --> RD[(Redis: answer cache)]
```

## The agent (`backend/app/agent/graph.py`)

```
START -> rewrite -> retrieve -> grade --enough evidence--> generate -> verify -> END
            ^                      |
            +---- broaden query ---+--no evidence, retries left
                                   +--no evidence, out of retries--> abstain -> END
```

- **rewrite** turns a follow-up ("and carried over?") into a standalone search query using the conversation.
- **retrieve** runs BM25 and vector search, merges them with RRF, then reranks the merged candidates.
- **grade** keeps only passages whose rerank score clears a threshold; if none do, it retries once with a widened query, then abstains.
- **generate** asks Claude to answer only from numbered passages and cite them.
- **verify** strips citations that point at passages that do not exist and flags answers with no valid citation as unverified.

## Run it

**Offline mode** (no API key, no services, no model downloads; SQLite + in-memory vectors + extractive answers):

```bash
make install
make backend      # http://localhost:8000/docs
make frontend     # http://localhost:3000   (second terminal)
```

Upload files from `sample_docs/` in the UI and ask, for example, "How many days of annual leave do I get?"

**Full stack** (Postgres, Redis, Qdrant, real embedding and reranking models, optional Claude answers):

```bash
cp .env.example .env     # set ANTHROPIC_API_KEY and LLM_PROVIDER=anthropic for Claude answers
docker compose up --build
```

| Variable | Offline default | Production value |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./data/app.db` | `postgresql+psycopg://...` |
| `QDRANT_URL` | unset (in-memory) | `http://qdrant:6333` |
| `REDIS_URL` | unset (in-memory) | `redis://redis:6379/0` |
| `EMBEDDER` / `RERANKER` | `hashing` / `lexical` | `fastembed` / `fastembed` |
| `LLM_PROVIDER` | `extractive` | `anthropic` |
| `API_KEY` | unset (open) | shared secret, held by the frontend proxy |

## API

| Endpoint | Purpose |
|---|---|
| `POST /documents` | Upload a file into a collection (idempotent by content hash) |
| `GET /documents`, `DELETE /documents/{id}` | List and remove documents; removal clears Postgres, Qdrant and BM25 |
| `POST /chat` | Ask a question; returns answer, citations, `grounded`/`abstained` flags and the agent trace |
| `GET /conversations/{id}` | Conversation history |
| `POST /feedback` | Thumbs up/down on an answer |
| `GET /collections`, `GET /health` | Housekeeping |

## What was verified, and what was not

**Verified in this build**
- 34 backend tests pass: chunking, BM25, RRF, both vector stores (in-memory and Qdrant's local mode), hybrid retrieval, collection isolation, index rebuild on restart and across processes, the LangGraph agent (grounded answer, retry then abstain, follow-up rewriting, citation verification), and the API (upload, PDF, dedupe, cache and cache invalidation, conversations, feedback, auth).
- The frontend typechecks and builds. Backend plus the Next.js proxy were exercised end to end (multipart upload, chat, error codes) in offline mode.

**Not verified (needs your environment)**
- Claude-written answers (`ClaudeGenerator`), the fastembed embedding and cross-encoder models, PostgreSQL, a Redis server, a Qdrant server, the Docker builds and compose file, the CI workflow, any AWS deployment, and `scripts/eval_ragas.py`. These are written against the documented APIs but have not been run.
- The offline retrieval check (`make eval-retrieval`) scores 11/11 on `eval/golden.jsonl`. That golden set is small and easy (four short documents, keyword-friendly questions); treat it as a regression test, not a benchmark. Quality claims need RAGAS scores on your own documents.

## Evaluation

- `python -m scripts.eval_retrieval`: hit rate@k and MRR against `eval/golden.jsonl`, offline, no API key.
- `python -m scripts.eval_ragas`: faithfulness, answer relevancy, context precision and context recall with Claude as judge (see the script header; install `requirements-eval.txt` in a clean virtualenv).

Replace `eval/golden.jsonl` and `sample_docs/` with real documents and questions written by people who know the answers.

## Design decisions

- **Hybrid retrieval:** BM25 finds exact terms (policy names, numbers, codes) that embeddings blur; vectors find paraphrases. RRF merges them without needing comparable scores.
- **Abstention over guessing:** the grade step and the verify step exist so that "not in the documents" is a normal outcome.
- **Tenancy by collection:** every query is filtered to one collection in the vector store, the BM25 index, and the database.
- **Chunks live in Postgres:** vectors and BM25 can be rebuilt from it, and deletion is one consistent operation.
- **Key stays server-side:** the browser only talks to the Next.js proxy.
- **Retries on a shared index:** the BM25 index is per process and refreshes when the collection's version changes.

## Limitations

- No per-user login or document-level permissions: access is by collection and one shared key.
- BM25 is in process memory; fine for thousands of chunks, not millions.
- PDF text extraction only (no OCR, no table-aware parsing); `.docx` is not supported.
- Answer quality depends on the generator and reranker you configure; the offline components match words, not meaning.
- No streaming responses and no rate limiting yet.

## Resume bullets (fill in the bracketed values from your own evaluation runs)

- Built an enterprise document Q&A system with a LangGraph agent (query rewriting, evidence grading, retry, abstention, citation verification) over a hybrid RAG pipeline: BM25 + dense vectors in Qdrant, Reciprocal Rank Fusion, and cross-encoder reranking.
- Served it with FastAPI and a Next.js chat UI showing inline citations and source passages, with PostgreSQL for documents, chats and feedback, and Redis answer caching with version-based invalidation.
- Evaluated with RAGAS on [N] questions: faithfulness [x], context precision [x], context recall [x]; retrieval hit rate@3 [x].
- Wrote 34 automated tests and containerised the stack with Docker Compose and GitHub Actions CI.

Describe AWS only as a reference design unless you have deployed and run it.
